package sales;

public class SalesActivityReport {

	public String toXml() {
		// TODO Auto-generated method stub
		return null;
	}

}
