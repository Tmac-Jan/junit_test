package sales;

import java.util.List;

public class SalesReportDao {

	public List<SalesReportData> getReportData(Sales sales) {
		// TODO Auto-generated method stub
		return null;
	}

}
