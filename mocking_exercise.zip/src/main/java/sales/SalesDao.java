package sales;

import java.util.List;

public class SalesDao {

	public Sales getSalesBySalesId(String salesId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<SalesReportData> getReportData(Sales sales) {
		// TODO Auto-generated method stub
		return null;
	}

}
