package parking;

public class Car {

	private String name = null;
	
	public Car(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
}
